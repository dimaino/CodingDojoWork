namespace FormSubmission.Models
{
    public abstract class BaseEntity {}
}