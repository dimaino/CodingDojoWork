using System.Collections.Generic;

namespace ConsoleApplication {
    public class Player {
        public string name;
        private List<Card> playersHand;
        public Player(string myName)
        {
            playersHand = new List<Card>();
            name = myName;
        }

        // Pick the to most card from the deck and add it to the players cards
        public void DrawFromDeck(Deck currentDeck)
        {
            if(currentDeck.getCardCount() >= 0)
            {
                playersHand.Add(currentDeck.SelectTopMost());
            }
            else
            {
                System.Console.WriteLine("Thats too many cards to draw!!!");
            }
        }

        // Pick a certain number of cards from the deck
        public void DrawFromDeck(Deck currentDeck, int num)
        {
            if(currentDeck.getCardCount() >= num)
            {
                for(int i = 0; i < num; i++)
                {
                    
                    playersHand.Add(currentDeck.SelectTopMost());
                }
            }
            else
            {
                System.Console.WriteLine("Thats too many cards to draw!!!");
            }
        }

        // discard the card at the current position.
        public Card Discard(int i)
        {
            Card myCard = playersHand[i];
            playersHand.RemoveAt(i);
            return myCard;
        }

        // Removes all Cards from players hands
        public void Discard()
        {
            playersHand.Clear();
        }

        // Prints out all cards in the players hands
        public override string ToString()
        {
            string str = "";
            foreach(var card in playersHand)
            {
                str += card + ", ";
            }
            return str;
        }
    }
}