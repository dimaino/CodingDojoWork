$(document).ready(function() {
    $.get("", function(response) {
        // Handle the response data

    })
})