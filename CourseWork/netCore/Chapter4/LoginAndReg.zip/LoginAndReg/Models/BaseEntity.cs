namespace LoginAndReg.Models
{
    public abstract class BaseEntity {}
}