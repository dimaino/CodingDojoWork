from __future__ import unicode_literals
from django.contrib import messages
from django.db import models
import bcrypt
import re
import math

NAME_REGEX=re.compile(r'^[a-zA-Z]{2,}$')
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
PASSWORD_REGEX = re.compile(r'^.{7,}$')
NUMBER_REGEX = re.compile(r'^[0-9]*$')

class UserManager(models.Manager):
    def isValidRegistration(self, userInfo, request):
        validUser = True
        if not NAME_REGEX.match(userInfo['first_name']):
            messages.warning(request, 'Last name needs to be greater than 2 characters and can only contain letters!')
            validUser = False
        if not NAME_REGEX.match(userInfo['last_name']):
            messages.warning(request, 'Last name needs to be greater than 2 characters and can only contain letters!')
            validUser = False
        if not EMAIL_REGEX.match(userInfo['email']):
            messages.warning(request, 'Email is not a valid email!')
            validUser = False
        if not PASSWORD_REGEX.match(userInfo['password']):
            messages.warning(request, 'Password is not long enough.')
            validUser = False
        if userInfo['password'] != userInfo['confirm_password']:
            messages.warning(request, 'Password match not confirmed.')
            validUser = False
        if self.filter(email = userInfo['email']):
			messages.error(request, "This email already exists in our database.")
			validUser = False
        if not NUMBER_REGEX.match(userInfo['birthday']) or not userInfo['birthday']:
            messages.warning(request, "Not a number!")
            validUser = False
        elif int(userInfo['birthday']) < 0 or int(userInfo['birthday']) > 120:
            messages.warning(request, "You age must be between 0 and 120 years of age :D")
            validUser = False
        if validUser == True:
            messages.success(request, "Success! Welcome, " + userInfo['first_name'] + "!")
            hashed = bcrypt.hashpw(userInfo['password'].encode(), bcrypt.gensalt())
            self.create(first_name = userInfo['first_name'], last_name = userInfo['last_name'], email = userInfo['email'], password = hashed, birthday= userInfo['birthday'])
        return validUser

    def UserExistsLogin(self, userInfo, request):
        validUser = True
        if self.filter(email = userInfo['email']):
            hashed = self.get(email = userInfo['email']).password
            hashed = hashed.encode('utf-8')
            password = userInfo['password']
            password = password.encode('utf-8')
            if bcrypt.hashpw(password, hashed) == hashed:
                messages.success(request, "Success! Welcome, " + self.get(email = userInfo['email']).first_name + "!")
                validUser = True
            else:
                messages.warning(request, "Unsuccessful login. Incorrect password")
                validUser = False
        else:
            messages.warning(request, "Unsuccessful login. Your email is incorrect.")
            validUser = False
        return validUser


class User(models.Model):
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)
    email = models.EmailField()
    password = models.CharField(max_length=200)
    birthday = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    userManager = UserManager()
