namespace RESTauranter.Models
{
    public abstract class BaseEntity
    {

    }
}