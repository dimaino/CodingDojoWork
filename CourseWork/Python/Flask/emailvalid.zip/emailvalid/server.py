from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re #import regex for validating
app = Flask(__name__)
mysql = MySQLConnector(app,'email')
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
app.secret_key = "ThisIsSecret!"


@app.route('/')
def index():
    query = "SELECT * FROM users"                           # define your query
    email = mysql.query_db(query)
    return render_template('index.html', makeupname=email )


@app.route('/email', methods=['POST'])
def create():
    if len(request.form['emails']) < 1:
        flash("Email cannot be blank!")
        session['print'] = 0
    elif not EMAIL_REGEX.match(request.form['emails']):
        flash("Invalid Email Address!")
        session['print'] = 0
    else:
        flash("Email was successfully entered!")
        query = "INSERT INTO users (email, created_at, updated_at) VALUES (:email, NOW(), NOW())"
        data = {
        'email': request.form['emails']
        }
        mysql.query_db(query, data)
        session['print'] = 1   
    return redirect('/')

@app.route('/remove_email/<id>', methods=['POST'])
def delete(id):
    print id
    query = "DELETE FROM users WHERE id= :id"
    data = {'id': id}
    mysql.query_db(query, data)
    return redirect('/')



app.run(debug=True)