
from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name ="index1"),
    url(r'^register$', views.register, name = "register1"),
    url(r'^success$', views.success, name = "success1"),
    url(r'^login$', views.login, name = "login1"),
]
