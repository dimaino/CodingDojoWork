namespace lostInTheWoods.Models
{
    public abstract class BaseEntity {}
}