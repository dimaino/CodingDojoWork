from django.shortcuts import render, redirect
from django.db.models import Count, F
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues":League.objects.all(),
		"teams":Team.objects.all(),
		"players":Player.objects.all(),
		"problem1":Team.objects.filter(league=League.objects.filter(name="Atlantic Soccer Conference")),
		"problem2":Player.objects.filter(curr_team=Team.objects.filter(team_name__contains="Penguins", location="Boston")),
		"problem3":Player.objects.filter(curr_team__league__name__contains="International Collegiate Baseball Conference"),
		"problem4":Player.objects.filter(curr_team__league__name__contains="American Conference of Amateur Football")&Player.objects.filter(last_name="Lopez"),
		"problem5":Player.objects.filter(curr_team__league__sport="Football"),
		"problem6":Team.objects.filter(curr_players__first_name="Sophia"),
		"problem7":League.objects.filter(teams__curr_players__first_name="Sophia"),
		"problem8":Player.objects.filter(last_name="Flores").exclude(curr_team__id=Team.objects.get(location="Washington",team_name="Roughriders").id),
		"problem9":Team.objects.filter(all_players__first_name="Samuel", all_players__last_name="Evans"),
		"problem10":Player.objects.filter(all_teams__team_name="Tiger-Cats"),
		"problem11":Player.objects.filter(all_teams__team_name="Vikings").exclude(curr_team__team_name="Vikings"),
		"problem12":Team.objects.filter(all_players__first_name="Jacob",all_players__last_name="Gray"),
		"problem13":Player.objects.filter(all_teams__league__name__contains="Atlantic Federation of Amateur Baseball Players")&Player.objects.filter(first_name="Joshua"),
		"problem14":Team.objects.annotate(num_players=Count('all_players')).filter(num_players__gte=12),
		"problem15":Player.objects.annotate(num_teams=Count('all_teams')).order_by("-num_teams")
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
