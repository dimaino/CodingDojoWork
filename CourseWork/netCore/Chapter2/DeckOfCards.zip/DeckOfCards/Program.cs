﻿using System;
using System.Collections.Generic;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Way 1
            // List<Card> c = new List<Card>();
            // string[] suits = new string[4] {"Hearts", "Clubs", "Spades", "Diamonds"};
            // foreach(string suit in suits)
            // {
            //     for(int i = 1; i <= 13; i++)
            //     {
            //         c.Add(new Card(suit, i));
            //     }
            // }
            // Deck someDeck = new Deck(c);
            // Player player1 = new Player("Bob");
            // someDeck.Shuffle();
            // player1.DrawFromDeck(someDeck);
            // player1.DrawFromDeck(someDeck);
            // player1.DrawFromDeck(someDeck);
            // player1.DrawFromDeck(someDeck);
            // player1.DrawFromDeck(someDeck);
            // System.Console.WriteLine(player1.ToString());
            
            // //Console.WriteLine(someDeck);
            // System.Console.WriteLine();
            // System.Console.WriteLine();
            // System.Console.WriteLine();
            
            // Way 2
            System.Console.WriteLine("Create a new deck:");
            
            Deck theDeck = new Deck();
            //Console.WriteLine(theDeck);
            theDeck.Shuffle();
            //System.Console.WriteLine(theDeck.SelectTopMost());
            //Console.WriteLine(theDeck);

            Player player1 = new Player("Daniel");
            player1.DrawFromDeck(theDeck, 5);
            Player player2 = new Player("Daniela");
            
            
            System.Console.WriteLine(player1.name + "'s hand: " + player1.ToString());
            System.Console.WriteLine(theDeck.getCardCount() + " Left in Deck");
        }
    }
}
