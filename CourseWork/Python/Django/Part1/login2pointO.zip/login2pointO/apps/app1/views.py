from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User

def index(request):
    context = {
        'something':User.userManager.all(),
        'hashed':User.userManager.values('password')
    }
    for value in context['hashed']:
        for i in value.values():
            print i
    return render(request, 'app1/index.html', context)

def register(request):
    if User.userManager.isValidRegistration(request.POST, request):
        return redirect ('success1')
    else:
        return redirect('index1')

def success(request):
    return render(request, 'app1/success.html')

def login(request):
    if User.userManager.UserExistsLogin(request.POST, request):
        return redirect ('success1')
    else:
        return redirect ('index1')
