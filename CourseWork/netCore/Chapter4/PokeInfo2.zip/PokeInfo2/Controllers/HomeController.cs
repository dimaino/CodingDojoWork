using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace PokeInfo2.Controllers
{
    public class HomeController : Controller
    {
        // // [HttpGet]
        [HttpGet]
        [Route("pokemon/{pokeid}")]
        public IActionResult QueryPoke(int pokeid)
        {
            var PokeInfo = new Dictionary<string, object>();
            WebRequest.GetPokemonDataAsync(pokeid, ApiResponse =>
                {
                    PokeInfo = ApiResponse;
                }
            ).Wait();
            // Other code
            ViewBag.Pokemon = PokeInfo;
            // var types = PokeInfo["types"];
            // foreach(var isd in (Dictionary<string,object>)types)
            // {
            //     System.Console.WriteLine(isd);
            //     //System.Console.WriteLine(isd["type"]);
            // }
            return View("Index");
        }
    }
}
